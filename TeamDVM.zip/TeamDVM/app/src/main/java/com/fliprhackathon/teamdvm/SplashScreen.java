package com.fliprhackathon.teamdvm;

public class SplashScreen {
}
